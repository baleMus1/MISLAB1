package com.example.lab1mis

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
