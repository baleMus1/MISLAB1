import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  final List<Product> products = [
    Product(
      name: 'iPhone 16',
      imageUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-16-ultramarine-c?wid=465&hei=465&fmt=webp',
      description: 'A17 chip'
          ' 128GB',
      price: 800.99,
    ),
    Product(
      name: 'iWatch',
      imageUrl: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxIQEBIPEBAQFRAVEBUWFRURFRcVFxYXFhYXFxUWFxYYHiggGBolGxUVITEhJSkrLi4vFx8zODMsNygtLisBCgoKDQ0NDg0NDysZFRkrKysrNy0rNzctKysrKysrLSsrKystKysrKysrKysrKysrKzcrKysrKysrKysrKysrK//AABEIAOEA4QMBIgACEQEDEQH/xAAcAAABBAMBAAAAAAAAAAAAAAAABQYHCAECAwT/xABYEAABAwIBBgcICwwJAgcAAAABAAIDBBEFBhIhMUFRBxMiYXGBkTIzUnKSobHRCBQjQkNTYnOissEVNFVjdHWCk7O00uEWJDU2g5TCw/BUoxhEZaTT4/H/xAAWAQEBAQAAAAAAAAAAAAAAAAAAAQL/xAAVEQEBAAAAAAAAAAAAAAAAAAAAEf/aAAwDAQACEQMRAD8AnFCEIBCEIBCEIBCEIBCRMpsqabD2Z07+WRyI2aXu6BsHObBRBlLwjVdWS1juIh8CIkOI+U/Weqw5kExYvlRSUtxNOwPHvG8p/W1tyOuyaOIcK8QuIKd7ueRwb5hf0qHDMSscYqJGquFCrd3AhZ4rbn6RKTJsva52uocPFAb9UBM0PWwKByyZW1btdTN5bvWuX9I6g/Dy+W71pCatpJWsF3FA4Y8pqkap5fLd617IMt6tmqeQ+Mc7610wJ8X2NC8jsRedqJUw0PChUN741kg5xY/RsPMnXhPCRSTWbLnROPhcpvaNPmVchXu3leiLEjvQq2dPUMkaHxva9h1OaQQesLqqyYDlTPSvz4JXMO0a2u8Zp0FTBkhwkQ1RbDU5sM50A39zeeYnuTzHtUU+0IQgEIQgEIQgEIQgEIQgEIQgEIQgEwsv+EJlFnU1Nmvq7co62xX8Le/5PWdx5cJmXoo2mkpXA1bhy3DTxLSPrkahs1nZeD3PJJJJJJuSdJJOsk7Sg711bJPI6WV7nyON3Ocbk/8ANy4ArCyFUbBbrQLcINgt2BatC9VPC5zmxsaXSPcGsaNZc42aB0khB7sAwWatnbT07buOl7z3MbdrnH0DWSkzLXJarw+XNqm3Y4kRysuY38wPvXW96dOg2uNKsPkbk2zDqZsQs6V1nTSeG/m+SNQG7nJRl5SGbDaxjWBzva73NBAPKYM4WB99caDvsoqqj4zqWBFzru/XdaqstBT85WRSO2Eda2utg8hBrmSN1tNubSvTS1ixHUkLqWsfrFnbwipP4P8AhHdBm01Y4up9AbIdLotwdtczzjnGgTPHIHAOaQWkAgg3BB0ggjWFUhudGdOrepL4M8ujSltLUuvSOPJcfgXH/bJ17teq6ipuQsA30jUsoBCEIBCEIBCEIBCEgZWZWQYcwGS75ng8XCwjPdbW430NYNrj0C5sCC+mNwk5eMw6PiIXNNa9vJBseKafhHDfuG3oCjvG+EasnveRsTdkcJeGgbLvBa9x2HTmnwQm07KKUEkSBpJuSxrW3O86DdUeFzZZXF5bK9ziXOdmucXE6SSdpJW4oZjqp6jqhkP+ldn5RynXUv8AofwrkcoX7al3awegIR0bhVQf/Lz9cbh6QurcFqfiH9dh6SvCcfPx7vL9S1ON/jnfrD60IU24JUfEu8pnrWsmGTt1wTW3hjiO0Cy8UeLPPczO6CWuHov517KfKgxH3R4B2FhJvb5Osecc6DjEblPzgjw4TYgZXC4ghLm+O/kNPkl/XZM6fLKjqOTOyQP1CcMF27s4g3c3mIPVrTw4G8SbHXuicRaeAhhB0FzDnAA7btzz1IJuQhCgrbwm5JnDqw5jf6rMS+EgaG+HFzZpOj5JGuxTPsrUZX5Ox4jSSUsmgnlRvtcxyC+Y8dtiNoJG1VhxCikp5ZIJm5ssbyx7dxG47QdYO0EFVHksiy3ssWRGlllrrLNkWQeqGW4zTqW0Tyx1tmzoXkYbL1Wz222jSPUipg4LMtLZlBUO5J0QPOw7IXHd4Pk7gpXVTqCoU/8ABvlT7dh4mZ16mJouTrkZqbJ07Hc9j75RTyQhCAQhCAQhCBFyvyijw2jkq5dOaLMZqL3nuGDr1nYATsVVcXysqKmWWeV2dNI67nnYB3LGt960bApE9kNjxkqY6JruRCwOcB8ZIL6ehmbbxyocQdpKl7u6e49f2LilXJzJ6pxCcU9JE57zrI7lg8J7tTW856Bc6FJ1VwDSxQPmfiEecyJzy1sJIu1pcWhxeNGi17dSCHEJaySyXqcUqBTUrQXWznOeSGMb4TyAbC9hoBPMpZpvY+i3umJHO2hkGgdZk09gQQYhT8z2P9P76vnPRGwfaV1bwA0e2squoRj7EFfEKXctuBKSkgfU0U7p2xtznxPaBJmjunMINnkDTm2BsDa50KIkHopaYyvDG2BO/UE46F89AYzLdrQ8OhnYbhrxyhp2adNiNm5N7Dn5sgdu09mvzXUm4Jxc7HU04vFI3NO8HY5u5wOkIJtyJykZiVIyoaW545ErWm4a8AE25iCHDmcEvqAOBKrkoMXqMLlOiVrm8xkh5bHjmdGXnn5O5T+gFVfLHExVYhVVDe5fO7NO9jeQw9bWtPWrEZfYmaXDKuZpzXiEtYdz5LRsPU54VYnRckWRGpWERm4WSFRhYIWUIjUrvTvXEhbRHSiuruTJzO0p25IYwaSphqL2ax4D+eN3JkB36DfpaE36CmbM/ind06OQRuva0gaXx33hzmCP/EvrAXehNx0t+xBaZCTsnZjJR0sjtbqaFx6XRtJ9KUVFCEIQCEIQVF4S60zYnVyHbUSAdDXFjfotCUuDTg3mxhxlLxFRskzHyaC9zgA4sY3fZzeUdAzhr1Jr5RS59RI47XuPaSVKfBPl1SYTg05nfnTmukMcDCDI+8MIBt71lweUdGg2udCCYcLwuiwekLYxHBTsGc97ja51Z0jzpc46uwDYF1r6xk+HSTxG8UtE6RhsRdr4i5psdI0EaCqtZb5c1eLSZ07s2FriY4GdwzYD8p1vfHebWGhWRwP+79P+Z4/3UIGp7HXDGx4bLU2GfNUuF9uZG0Bo6nGQ9a0yo4b4aSqmpYqN83EyOjc8yiMF7DmuAGY4kAgi+2yVuAb+xYfnpvrlV3yx/tGu/Laj9q9BLJ9kJ/6X/wC6/wDpWh9kG7Zhjf8AMn/4lCKEFw8hsqGYrRMrGRmO7nNewnOzXNOkZ1hcWsb2GtVUyxoBT4jWQNADI6qZrANQaHnMHk2U++x5/sh35ZL9WNQjwm/2xX/lUnpQIFCfdGp85NSnkHbYJiUh5belK9XXFkYiabZxOcRrzc4i3Xp7ED5rKgNx+grICHtBp/bDoznBnLMMmeR3Nos06disVFK17Q5jg5p1FpBB6CFXfg+wCOpZeUO4vU1rXFvSbtIN+fWnPguLfcnG/ueC8Us4jLWmR72kSCwfZ5OZI14cCQQ1zQbi4CB0cNbj9yXjYZ4Qep4PpAUDgaB0Kx/CPhZqsLqomgl4jEjANZdE4SBo5zm261W2N1wqjk+mMYjce5ka4jmzZHsI6eSD0OC1K2naTYXNgSQNl3ZoJ681vYFyLXINli614tyOKcg2WLrHEuRxDkR1LzoAOm4sRs50rUzTazRdx0NA2k6AO1J1PFY3OtPjgxwj21iEVxeOH3d+67COLHTnlp6GlFTxh9NxUUcQ1MjYzyWgfYvQhCihCEIBYKysFBSrFu+leJezFe+FeNAK3GB/3fp/zPH+6hVHVuMD/u/T/meP91CBD4ApQ7BmAHS2omaeY3DvQ4KF8uMkK9uJVlqKqe11VK9j44Xva5r3l7SHNBB0OHQbjYnBwIZexYc+Sjq3ZlNM4PbIdUctg051tTXAN5WzNF9BJFgYMYppGh8dTTuaRcObKxwPQQUFQxkniH4Prv8ALy/wrYZIYj+Da/8Ay038Kt6cUg+Ph/WN9a1OLU//AFEH6xnrQNHgXwOaiwpkdTG6OV80khY7Q5odYNDhsNm3tsuq88Ikwfi1e4avbkw8l5b9isPlxwm0VBBJxVRDPV5pEcUThJZ2wyFuhrRrsTc7FVmaVz3Oe4kuc4lxOskm5J60Gafu29K9VaeWOg/WcvLT923pCWKmhdJHnsBLmufcDWRnHV0fagl7gxI9rMtz+n/8SJwsX+7NHmd89qxavnJ/sukzg8ymZStLZM4tGkWFzziw6NfqT1wLCvuvjIxJrZPasLYwHPjcxvud7RtLrF7y+5dos1txpLgRVTEq2cIuT/tGvliaLQv91i3BjyeSPFcHNtuA3qyajnhtwfjaNlU0cunksT+LlIafpcWe1REF3WboIWFUbXRdYWUGboQshFbsUy8BcLfa9VJb3Q1DWE/IbG0t+k+RQ5EFL/AXJ7nVs3Oid5QkH+lESkhCFFCEIQCwVlYKClOK98K8a9mK98K8aAVuMD/u/T/meP8AdQqjq3GB/wB36f8AM8f7qEFYck8mKnE6gU1K0F1s5znmzGNHvnkA2FyBoBOlS1S+x+bm+64i7O3RwAAdZfp8yWfY64W2PDpamwz5qgi+3MjAa0eUZD1rplVw1U1FVS0jKaWZ0Tyx7w9rG57dDg3QSbG4OrSCgSh7H+H8ITfqm/xLP/h/g/6+b9U31rT/AMQMX4Ol/XN/gQPZAxfg6W3zzf4EDTy44G6nD4H1UEzamGMF0gzDHIxo1uzbkOaBrIOjXa17Rirl5L49DidHHVwg8XIHAskAuCCWua4ajpB6QqkZU4cKWuqqZoIbFUysbfTyWvIb9GyBPp+7b0hPPAP9bvrFMym7tvSnpgH+t31iqFDhCgjjbh742sbI90vGFgDXOF4czPI0kd3a/OrMxsDQGtAAAsABYDoCrRwkxNDcNkAGe4ytcdpax0TmjoBe49asyoBeDH6AVNLUU5+EhewdJaQD1GxXvQgqQ7fvC1ShjcIjqJ4xqZPI0fovcPsXgVQWWUICKyAsgIWQiOsY0HoUq8BjuXVjfHCewyetRWO5PQpQ4ED7tUD8QzzPPrQS8hCFFCEIQCwVlYKCplCBZ+gd8P1Wr05o3DsXmoNT/nD9Vq7zzNY0ucbAINswbh2JuuxGYTlgmlzONzc3Pdm5uda1r2tbRZe449F4MnYPWvVSVEUulgbnDSbtAI5/5oEzGK+WOXNjllY3NBsx7mi/QClim5TGOdpJY0knSSSBcknWU38oe/fohOCj73H8230BB0zBuHYjMG4di2QgQ8Zr5opM2KaVjc0HNY9zRc3ubApUoznRsc7lOLQSXaSSRpJJ1lIWUXfh4g9JS7h3eY/Eb6EDfxAf1p3jN9ATkwR1ho157gL7y8gechNzEfvp3jN+qE48E1D54ftVVLXCLEI4sLzRpc+oDnbX6acco7ebdotqVlFW7hO71hPzk/pplZFRAhCEFX8qvv6r/K5/2r0jpSx6TPqah/hVEru2Rx+1JyqBAWHOA1myywg6QitlsFhZaiOr+4PUpQ4ER7vUfMM87z6lF83cjpClXgQZ7pVndFCO10n8KCWUIQooQhCAWCsrBQVMoNT/AJw/VakrKWXlMZstndpsPQe1K1Bqf84fqtSJlJ31vzY9LkGKfBHvYH5zRcXAN9uq64UBdFUNB1h+aes2Kc9L3tniN9ATcqfvs/Oj0hB3ykhIe1+wtt1j+R8y5UuNPY0MzWkAWF73snFPC17S1wuCkt2AM2PeOmxQef8ApA74tvaVn+kDvi29pXX+j7fjD5I9ax/R4fGnyf5oEerqTK8vda53agnXh3eY/Eb6E2sTpBE/MBJ5INz1py4d3mPxG+hAg1/30fGH1QnFgmofPD9qm7X/AH07xh9UJxYLqHzw/aqhe4Tu9YT85P6aZWQVcOEscjCR+Mn+tTqx6gFyqphHG+Q6msc49QJ+xdUjZZTZmHVjhr9qy26SwgelBWSQ79a70VLnm51BcJNaXsPlibE1rtdrm28qhCxOGyUcIobt0jQQutfTskzc12guGsW57bjqXva1wGaGkBQN+rh4t7mbjoO8bFzYvXi4tJp15o9JXkj1qo6T+8HOpj4EobRVUm+SNnkNLv8AcUOvF3tG4KdeCCmzMPL/AIyokd5IbH/tlA+EIQooQhCAQhCCp8LM18zDrbM4dgA+xIOUnfW/Nj0uTtx+nMOJV0J2VLyOgvcR5i1NbKWPlsfsLbdhv9qBbpe9s8RvoCblV99/4o9IXrpcdDWNa5hJAAuDrsvBTuMtQ11tLpAegXufMEHvxqukjlzWPIGaDawSzTOJYwnWWNJ6SAkHKSO0jXbCy3WDp9IW9FjgYxrHMJLRa4OwakC+hJAx9ngP83rWfu/H4Mnm9aDwZRd+/QHpKXcO7zH4jfQmviNVxshfaw1AcwTrpGZsbGnWGNB7EDdrT/WneMPQnJg3cg7A/OPQH5x8wTYLs6pcfxjuy5TwyajJDN9gqFrhBbnPwaPaZX/SkgH2KxSrpi8fGY3hVEzS1hpi5p05t5jK8C/cjMaw2G7RoVi1AJAy9bfDKz8neewXPoS+vJi9Hx9PNAfhIXs8tpb9qCqsmtLOHxM4sSO083QkidhBIIII0EHWDtBWYagtBbsKo6V9YXTMtqadAS3SVpaNPc86auac69l7pKkluaNSg3xCo4yRz9hOjoGgLnCNK5Bbl+aCVUdqfTITu0disbkFS8VhtI21rwh56ZSZD9dV4wmlc8tjb3cj2sb4zyGjzlWjgiDGtY3Q1rQ0dAFgordCEIBCEIBCEIIB4cMMNLiUdaB7lURgPI8JgDHfR4o89imbVU7ZWZrtIOkEbNxBVjsvcl2YpRSUriGyd3E8+9kbe1+Yglp5nFVfPtiikkpp4X3ieWuBHKYd24jaNhBBBsUHN2T26XRzt/mvbh2FthOdcuda1zot0BbRYtC739uZwI/kuorovjY/KCDNZStlbmu6iNYO9Ir8n3+9ew9Nx60tirjOqSPyh61uJm+E3tCBvfcGXwo+0+pY+4Uu9nafUnGHjeO1BeN47UCPQYJmuDpCDY3DW+a5+xKWIVPFRufttYc5Or19S0qMSiYNLwTubpPm1dabuI17pnXOho1D7elBpQNu+20i3b/wnqUkYDxcLTPM7NijF3H0NA2uOoBRrT1DonBzbZw3i6WKOOatLeNc9zA4BjGjunHQGtaNukC+vYgkDgbgfiOOTYlI3kxNdJruGukBihj57R59j8hWETV4OclG4ZRiLNaJpDxk2bqziAA0HaGgAc5zjtTqQC5VdQ2KN8rzZjGOe47mtBJPYF1TE4YsZ4jDzA0+6VLsznzBZ0h6LWb+mgg2vqzUSSTuADnyOe4DYXuLtHNpXkK6SNtpGted0u/R/wA3qo6BZXHjRvWDONmlB6L2WkXujh4IXANLterclKhjQPLg1w7jsSp225MedM7oYOT/ANx0anxRrwMYXaOescO7cImeLHpeRzFzrf4akpRQhCEAhCEAhCEAmplrkPDiI4wER1TW5rZc24cNjJW6M9t9WkEbDpILrQgrHlLkNUUhJqKazR8LHy4iN/GEANHM6x5k3XYHovxb7bwLjtaSrfKLOFDg2E+dX4e3MqQLyxR8njgNbmgfC/W6dYQccHb4L/Jf6locJbuf5L/Uu3tiUfDTj/Ef610bXTD4aXreT6VSvGcJb8rsd6lqcKbvPnSkMQn+Nd1hp9IWRiE/xp8iL+BAmDDG+C49TvSbBdocCzjqI6NJXvGIT/G/9uH+BbGtmIsZX/o2Z9QBB5pcn44gDI55ee5ZcC/ObaQ0b9G5SPwL4MySt4xw5FNFnNHy3HNaT0DPPTY7FH8DRe+83PPzlSZwMVwjrpYDo46Dk87oznZvkuef0UE1IQhQCrxwj4/7ernuYbwRe5x7iGnlPHjOvp3Bqk3hVyp9qUxponf1idpGjWyM6HO5idLR1nYoJJQYcVzMd1sStc5VGjaUOdmtF3HULXJ26h0LVrAlOlxd8MEkETWMMtxLKNMj2H4IO95HvA0u2m2hJ6DDRcpVoadzi2OMXke5rGDe5xAaO0heKmj0qT+CDJ/jZ3Vzx7nDdkV/fSkcp3Q1pt0u5kEo4BhbaSmhpmao4w0nwna3O63EnrSghCihCEIBCEIBCEIBCEIBCEIIk4V+DwyF+IUTLv0unhYNLt8rB4XhN26xpvnQyFcFRXwk8GYmL6ygYBLpdLCNAfvfHufvbt16+6CE1kLeSItJBBBBIIIsQRrBGwrWyqNmrYLQLcIOrClPDK58Mkc8TrSxvDmnnGw7wdRG0EpJBXaOSyCzuTGOx19Mypi0X0PZtY8d0w9G/aCDtXPKrKKLD4DNKbuNxHHexe7dzAbTs6bAwXkllRNh8plhs5rhaSJxs14Hcm+xwJ0HnI2pKyix+etmdNUOu46ABoa0bGtGwf8ADc6VFa41i0lXO+omdnPe653DcANgA0AJPLloXLCqOgXNztNgFi6EGbreNt1hjLpQw6hkmkZDCwvlebNa3WT9g2knQALoPbk9g0lZPHSwjlv1u2MYO6e7mA7SQNqsbg+Gx0sEdNCLRxtsN52lx3km5J3lIuQuSTMNgsbOqZLGWQbxqY35Av16TzBzKKEIQgEIQgEIQgEIQgEIQgEIQgEIQgZ2WnB/T4heVtoqq3fGjQ/cJG7fG19NrKFMoskKqhdaeIht7B7eUx3Q4eg2PMrOLWWMOBa4BzSLEOFwRzg60FSTGQsZqsTjPBxQVFy2MwvO2E2HkG47LJmYlwQTNuYJ4njc8Fh+0edVEU2WQnlW8HVfHrpnuH4vNf5mklI9Rk5UR93BK3xmOHpCBKjksups7XrXV1A8bCtfajtxQeZ1ORq0rm+Nx1r3CJ25eukwqol71BK/xGOd6AgR2QncurIE9sM4OMQnteFsTd8zg36Iu7zJ8YDwUU8RD6qR07vAHIj67HOd2joQRdk3kzU178ynju0GzpHaI2dLt/MLlTjkdkdBhrORy53Cz5nDSfktHvW32dt0v01OyJgjjY1jGiwawBoHQAuqihCEIBCEIBCEIBCEIBCEIBCEIBCEIBCEIBCEIBCEIBCEIEnFtabs+tCEChhusJzt1BCEGUIQgEIQgEIQgEIQgEIQgEIQg//Z',
      description: '45mm',
      price: 600.99,
    ),
    Product(
      name: 'MacBook Air',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTEbbt5FklssIL-g4uIYqTyyGIgvtNKotPvw&s',
      description: ' M3 Chip '
          '13inch display '
          'RAM 8GB '
          'SSD256 ',
        price :1000.99,
    )


  ];

  HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:const Text('215081'),
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(8.0),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount:2,
          childAspectRatio: 0.75,
          crossAxisSpacing: 8.0,
          mainAxisSpacing: 8.0,
        ),
        itemCount: products.length,
        itemBuilder: (context, index) {
          final product = products[index];
          return GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ProductDetailsScreen(product: product),
                ),
              );
            },
            child: Card(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Image.network(
                      product.imageUrl,
                      fit: BoxFit.cover,
                      width: double.infinity,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(9.0),
                    child: Text(
                      product.name,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 9.0),
                    child: Text('\$${product.price}'),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class Product {
  final String name;
  final String imageUrl;
  final String description;
  final double price;
  Product({
    required this.name,
    required this.imageUrl,
    required this.description,
    required this.price,
  });
}

class ProductDetailsScreen extends StatelessWidget {
  final Product product;
  const ProductDetailsScreen({super.key, required this.product});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(product.name),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(product.imageUrl),
            const SizedBox(height: 16.0),
            Text(
              product.name,
              style: const TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8.0),
            Text(product.description),
            const SizedBox(height: 8.0),
            Text('Price: \$${product.price}'),
          ],
        ),
      ),
    );
  }
}